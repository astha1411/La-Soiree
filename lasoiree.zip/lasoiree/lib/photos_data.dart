import 'package:flutter/material.dart';

class PhotoData {
  static final getData = [
    {
      'name': 'Precious Moments',
      'image':
          'https://vshoot.com/wp-content/uploads/2019/02/vshoot-wedding-photoshoot-ideas.jpg',
      'location': 'Thane',
      'ratings': 4
    },
    {
      'name': 'Photographica55',
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrjWWWLX_w-AqL6W6NxM9qRz5UMNq9pp7faQ&usqp=CAU',
      'location': 'Powai',
      'ratings': 4
    },
    {
      'name': 'The Pause',
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjZ1SzdxJNKP-V_OEpohJ22rg-Vi80rw18Ig&usqp=CAU',
      'location': 'Thane',
      'ratings': 2
    },
  ];
}
