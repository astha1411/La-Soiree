class CurrentOrders {
  static final getData = [
    {
      'name': 'Brownie Point',
      'category': 'Cakes & Desserts',
    },
    {
      'name': 'The Dukes',
      'category': 'Bands & DJs',
    },
    {
      'name': 'Candid Clicks',
      'category': 'Photographers & Video',
    },
  ];
}
