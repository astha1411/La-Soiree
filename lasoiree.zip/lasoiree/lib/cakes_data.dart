import 'package:flutter/material.dart';

class CakesData {
  static final getData = [
    {
      'name': 'Z Sweetest Sin',
      'image':
          'https://i.pinimg.com/originals/b0/fa/29/b0fa2934176e7dd0abc9769c20ef7c09.jpg',
      'location': 'Thane',
      'ratings': 3
    },
    {
      'name': 'Hey Sugar',
      'image':
          'https://ichef.bbci.co.uk/food/ic/food_16x9_832/recipes/cupcakes_93722_16x9.jpg',
      'location': 'Powai',
      'ratings': 4
    },
    {
      'name': 'Brownie Point',
      'image':
          'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhLoxQEomwDveWGgoJQcR6HWuSZ1xFJm7ZVw&usqp=CAU',
      'location': 'Thane',
      'ratings': 2
    },
  ];
}
